#!/usr/bin/python
# Writer (c) 2012, MrStealth
# Rev. 1.0.2
# -*- coding: utf-8 -*-

import re
import sys
import urllib
import urllib2
import xbmcplugin
import xbmcgui
import xbmcaddon

import XbmcHelpers
common = XbmcHelpers

### TODO:
# - genres listing
# - pagination

class FirstTV():
    def __init__(self):
        self.id = 'plugin.video.1tv.ru'
        self.addon = xbmcaddon.Addon(self.id)
        self.icon = self.addon.getAddonInfo('icon')
        self.path = self.addon.getAddonInfo('path')
        self.profile = self.addon.getAddonInfo('profile')

        self.xpath = sys.argv[0]
        self.handle = int(sys.argv[1])
        self.params = sys.argv[2]

        self.language = self.addon.getLocalizedString

        self.url = 'http://www.1tv.ru'
        self.stream_url = 'http://stream.1tv.ru'
        self.archive_url = 'http://www.1tv.ru/projects/'
        self.video_stream_url = 'http://www.1tv.ru/owa/win/one_sp_common.promo_single_xml'

        self.playlist_url = 'http://stream.1tv.ru/nplaylist/1tvch.xml'
        self.live_stream_url = 'http://cdn9.1internet.tv/hls-live2/livepkgr/_definst_/'
        self.streams = {'1': '1tv/1tv1.m3u8', '2': '1tv/1tv2.m3u8', '3': '1tv/1tv3.m3u8'}

    def main(self):
        print "PARAMS:"
        print self.params

        params = common.getParameters(self.params)
        mode = params['mode'] if 'mode' in params else None
        url = urllib.unquote(params['url']) if 'url' in params else None
        page = int(params['page']) if 'page' in params else 1
        project_id = params['project_id'] if 'project_id' in params else None
        video_id = params['video_id'] if 'video_id' in params else None

        if mode == 'play_stream':
            self.play_stream(url)
        if mode == 'play_video':
            self.play_video(project_id, video_id)
        if mode == 'live':
            self.live()
        if mode == 'project':
            self.project(project_id, page)
        if mode == 'projects':
            self.projects()
        elif mode is None:
            self.index()

    def index(self):
        uri = sys.argv[0] + '?mode=live'
        item = xbmcgui.ListItem(self.language(1000), iconImage=self.icon, thumbnailImage=self.icon)
        xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

        uri = sys.argv[0] + '?mode=projects'
        item = xbmcgui.ListItem(self.language(1001), iconImage=self.icon, thumbnailImage=self.icon)
        xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

        xbmcplugin.endOfDirectory(self.handle, True)

    def live(self):
        uri = sys.argv[0] + '?mode=play_stream&url=%s' % self.live_stream_url + self.streams['1']
        item = xbmcgui.ListItem('%s 1 (640x360)' % self.language(1002), iconImage=self.icon, thumbnailImage=self.icon)
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(self.handle, uri, item, False)

        uri = sys.argv[0] + '?mode=play_stream&url=%s' % self.live_stream_url + self.streams['2']
        item = xbmcgui.ListItem('%s 2 (640x360)' % self.language(1002), iconImage=self.icon, thumbnailImage=self.icon)
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(self.handle, uri, item, False)

        uri = sys.argv[0] + '?mode=play_stream&url=%s' % self.live_stream_url + self.streams['3']
        item = xbmcgui.ListItem('%s 3 (1280x720)' % self.language(1002), iconImage=self.icon, thumbnailImage=self.icon)
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(self.handle, uri, item, False)

        xbmcplugin.endOfDirectory(self.handle, True)

    def projects(self):
        print "Videoarchive: %s" % self.archive_url

        response = common.fetchPage({'link': self.archive_url})
        content = common.parseDOM(response['content'], 'div', attrs={'id': 'list_abc_search'})

        projects = common.parseDOM(content, 'h3')
        titles = common.parseDOM(projects, 'a')

        links_container = common.parseDOM(content, 'h5')
        links = common.parseDOM(links_container, 'a', ret='href')
        images = common.parseDOM(content, 'img', ret='src')

        infos_container = common.parseDOM(content, 'p')
        infos = common.parseDOM(infos_container, 'span')

        genres = common.parseDOM(content, 'div', attrs={'class': 'tags'})

        for i, title in enumerate(titles):
            title = self.encode(common.stripTags(str(title)))
            genre = self.encode(genres[i])
            info = self.encode(common.stripTags(infos[i])).replace('  ', '')
            project_id = links[i].split('&')[0].split('/')[-1].replace('si=', '')

            uri = sys.argv[0] + '?mode=project&project_id=%s' % project_id
            item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=images[i])
            item.setInfo(type='Video', infoLabels={'title': title, 'genre': genre, 'plot': info})
            xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

        xbmc.executebuiltin('Container.SetViewMode(52)')
        xbmcplugin.endOfDirectory(self.handle, True)

    def project(self, project_id, page):
        url = "http://www.1tv.ru/owa/win/one_sp_editions.editions_list?p_pagenum=%d&sn_id=%s&w_id=&nxt=0" % (page, project_id)

        content = common.fetchPage({'link': url})['content']
        videos = common.parseDOM(content, 'li')

        link_container = common.parseDOM(videos, 'p')
        text_container = common.parseDOM(videos, 'h3')

        titles = common.parseDOM(text_container, 'a')
        links = common.parseDOM(link_container, 'a', ret='href')
        images = common.parseDOM(videos, 'img', ret='src')

        dates = common.parseDOM(videos, 'div', attrs={'class': 'date'})
        infos = common.parseDOM(videos, 'p')

        for i, title in enumerate(titles):
            title = self.encode(title)
            date  = self.encode(dates[i]).replace('\n', '').split(',')[0]
            info  = self.encode(common.stripTags(infos[i])).replace('  ', '')

            video_id = links[i].split('/')[-1]

            uri = sys.argv[0] + '?mode=play_video&project_id=%s&video_id=%s' % (project_id, video_id)
            item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=images[i])
            item.setInfo(type='Video', infoLabels={'title': title, 'genre': date, 'plot': info, 'overlay': xbmcgui.ICON_OVERLAY_WATCHED, 'playCount': 0})
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(self.handle, uri, item, False)

        self.project_paginate(project_id, page)

        xbmc.executebuiltin('Container.SetViewMode(52)')
        xbmcplugin.endOfDirectory(self.handle, True)

    def project_paginate(self, project_id, page):
        uri = sys.argv[0] + '?mode=project&project_id=%s&page=%d' % (project_id, page+1)
        item = xbmcgui.ListItem('Next page %s' %project_id, iconImage=self.icon, thumbnailImage=self.icon)
        xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

    # def videos(self, url):
    #     print "Get videos for %s" % url
    #     response = common.fetchPage({'link': url})
    #     content = common.parseDOM(response['content'], 'div', attrs={'id': 'list_editions'})
    #     videos = common.parseDOM(content, 'li')

    #     link_container = common.parseDOM(videos, 'p')
    #     text_container = common.parseDOM(videos, 'h3')

    #     titles = common.parseDOM(text_container, 'a')
    #     links = common.parseDOM(link_container, 'a', ret='href')
    #     images = common.parseDOM(videos, 'img', ret='src')

    #     dates = common.parseDOM(videos, 'div', attrs={'class': 'date'})
    #     infos = common.parseDOM(videos, 'p')

    #     for i, title in enumerate(titles):
    #         title = self.encode(title)
    #         date  = self.encode(dates[i]).replace('\n', '').split(',')[0]
    #         info  = self.encode(common.stripTags(infos[i])).replace('  ', '')

    #         project_id = url.split('/')[-1].replace('si=', '')
    #         video_id = links[i].split('/')[-1]

    #         uri = sys.argv[0] + '?mode=play_video&project_id=%s&video_id=%s' % (project_id, video_id)
    #         item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=images[i])
    #         item.setInfo(type='Video', infoLabels={'title': title, 'genre': date, 'plot': info, 'overlay': xbmcgui.ICON_OVERLAY_WATCHED, 'playCount': 0})
    #         item.setProperty('IsPlayable', 'true')
    #         xbmcplugin.addDirectoryItem(self.handle, uri, item, False)

    #     xbmc.executebuiltin('Container.SetViewMode(52)')
    #     xbmcplugin.endOfDirectory(self.handle, True)

    # def get_video_url(self, project_id, video_id):
    #     playlist_url = "%s?pid=0&sn_id=%s&ed_id=%s" %(self.video_stream_url, project_id, video_id)
    #     print "Get video url from: %s" % playlist_url

    #     request = urllib2.Request(playlist_url, headers={"Host" : "www.1tv.ru"})
    #     content = urllib2.urlopen(request).read()
    #     links = common.parseDOM(content, 'media:content', ret='url')
    #     link = links[0] if links else None
    #     return link

    def play_video(self, project_id, video_id):
        # url = self.get_video_url(project_id, video_id)
        playlist_url = "%s?pid=0&sn_id=%s&ed_id=%s" %(self.video_stream_url, project_id, video_id)
        # print "Get video url from: %s" % playlist_url

        request = urllib2.Request(playlist_url, headers={"Host" : "www.1tv.ru"})
        content = urllib2.urlopen(request).read()
        links = common.parseDOM(content, 'media:content', ret='url')
        url = links[0] if links else None

        if url:
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(self.handle, True, item)
        else:
            self.showErrorMessage(self.language(1004).encode('utf-8'))

    def play_stream(self, url):
        item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(self.handle, True, item)

    # Python helpers
    def encode(self, string):
        return string.decode('cp1251').encode('utf-8')

    def showErrorMessage(self, msg):
        header = self.language(1003).encode('utf-8')
        xbmc.executebuiltin("XBMC.Notification(%s,%s, %s)"%(header, msg, str(5*1000)))

FirstTV().main()

# class URLParser():
#     def parse(self, string):
#         links = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', string)
#         print "Parser %s" % links
#         #return list(set(self.filter(links)))
#         self.filter(links)

#     def filter(self, links):
#         links = self.strip(links)
#         video_urls = []

#         for link in links:
#             if link.endswith('.mp4') or link.endswith('.flv'):
#                 video_urls.append(link)

#         return video_urls
#         # return [l for l in links if l.endswith('.mp4') or l.endswith('.mp4') or l.endswith('.txt')]

#     def strip(self, links):
#         return [l.replace('"', '') for l in links]



#     def find_url(self, string):
#         urls = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', string)
#         return urls

#     def find_video_url(self, links):
#         video_urls = []

#         for link in links:
#             link = link.replace("'", "").replace(",", "")
#             if link.endswith('.mp4') or link.endswith('.flv'):
#                 print "Link endwith .mp4 %s" % link
#                 video_urls.append(link)
#             else:
#                 print "Not a video URL %s" % link

#         return video_urls


    # def catalog(self, url):
    #     print 'Get catalog items for: %s' % url

    #     response = common.fetchPage({'link': self.videoarchive_url})
    #     content = common.parseDOM(response['content'], 'div', attrs={'class': 'tv_rightcol'})

    #     videos = common.parseDOM(content, 'li')

    #     img_container = common.parseDOM(videos, 'div', attrs={'class': 'img low'})
    #     link_container = common.parseDOM(videos, 'div', attrs={'class': 'play'})
    #     text_container = common.parseDOM(videos, 'div', attrs={'class': 'txt'})

    #     dates = common.parseDOM(videos, 'div', attrs={'class': 'date'})
    #     titles = common.parseDOM(text_container, 'a')
    #     links = common.parseDOM(link_container, 'a', ret='href')
    #     images = common.parseDOM(videos, 'img', ret='src')

    #     # print len(dates)
    #     # print len(titles)
    #     # print len(links)
    #     # print len(images)

    #     for i, title in enumerate(titles):
    #         title = "%s (%s)" % (self.encode(self.quotes(title)), self.encode(dates[i]))
    #         url = urllib.quote(self.url + links[i])

    #         uri = sys.argv[0] + '?mode=get_and_play&url=%s' % url
    #         item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=images[i])
    #         xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

    #     xbmcplugin.endOfDirectory(self.handle, True)

    # def catalog(self):
    #     print 'Get catalogs'

    #     response = common.fetchPage({'link': self.videoarchive_url})
    #     akordion = common.parseDOM(response['content'], 'div', attrs={'id': 'AKordionId'})
    #     items = common.parseDOM(akordion, 'li')

    #     for catalogid, item in enumerate(items):
    #         subcat = common.parseDOM(item, 'span')

    #         if subcat:
    #             # print 'Show subcategory'
    #             title = self.encode(common.parseDOM(item, 'span')[0])
    #             uri = sys.argv[0] + '?mode=subcatalog&catalogid=%d' % catalogid
    #             item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=self.icon)
    #             xbmcplugin.addDirectoryItem(self.handle, uri, item, True)
    #         else:
    #             try:
    #                 # print 'Show item'
    #                 title = self.encode(common.parseDOM(item, 'a')[0])
    #                 link = self.videoarchive_url + common.parseDOM(item, 'a', ret='href')[0]

    #                 uri = sys.argv[0] + '?mode=show&url=%s' % self.live_stream_url + self.streams['3']
    #                 item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=self.icon)
    #                 xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

    #             except IndexError:
    #                 pass

    #     xbmcplugin.endOfDirectory(self.handle, True)

    # def subcatalog(self, catalogid):
    #     print 'Get subcatalog: %d' % catalogid

    #     response = common.fetchPage({'link': self.videoarchive_url})
    #     akordion = common.parseDOM(response['content'], 'div', attrs={'id': 'AKordionId'})
    #     catalogs = common.parseDOM(akordion, 'li')

    #     subcatalog = catalogs[catalogid]
    #     subcatalog_title = self.encode(common.parseDOM(subcatalog, 'span')[0])

    #     titles = common.parseDOM(subcatalog, 'a')
    #     links = common.parseDOM(subcatalog, 'a', ret='href')

    #     for title in titles:
    #         title = common.stripTags(self.encode(title))
    #         uri = sys.argv[0] + '?mode=show&url=%s' % self.live_stream_url + self.streams['3']
    #         item = xbmcgui.ListItem(title, iconImage=self.icon, thumbnailImage=self.icon)
    #         xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

    #     xbmcplugin.endOfDirectory(self.handle, True)

#!/usr/bin/python
# Writer (c) 2012, MrStealth
# Rev. 1.0.0
# -*- coding: utf-8 -*-

from unified_search import UnifiedSearch
UnifiedSearch().main()

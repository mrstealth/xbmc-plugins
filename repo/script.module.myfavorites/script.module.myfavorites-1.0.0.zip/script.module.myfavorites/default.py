import xbmc
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.myfavorites')
plugin = "MyFavorites-" + "1.0.2"

#!/usr/bin/python
# Writer (c) 2012, MrStealth
# Rev. 1.0.0
# -*- coding: utf-8 -*-
import sys, os, timexbmcaddon

addon = xbmcaddon.Addon(id='script.module.translit')
addon_path     = xbmc.translatePath( addon.getAddonInfo('path') )
addon_profile  = xbmc.translatePath( addon.getAddonInfo('profile') )

BASE_RESOURCE_PATH = os.path.join( addon_path, 'resources', 'lib' )
sys.path.append (BASE_RESOURCE_PATH)

class Translit():
    def __init__(self):
        self.transtable = (
                ## upper
                # three-symbols replacements
                (u"Щ", u"Shh"),
                (u"Щ", u"SHH"),

                # two-symbol replacements
                (u"Ё", u"Jo"),
                (u"Ё", u"JO"),
                (u"Ж", u"Zh"),
                (u"Ж", u"ZH"),
                (u"Ч", u"Ch"),
                (u"Ч", u"CH"),
                (u"Ш", u"Sh"),
                (u"Ш", u"SH"),
                (u"Ы", u"Y"),
                (u"Э", u"Je"),
                (u"Э", u"JE"),
                (u"Ю", u"Ju"),
                (u"Ю", u"JU"),
                (u"Я", u"Ja"),
                (u"Я", u"JA"),

                # one-symbol replacements
                (u"А", u"A"),
                (u"Б", u"B"),
                (u"В", u"V"),
                (u"Г", u"G"),
                (u"Д", u"D"),
                (u"Е", u"E"),
                (u"З", u"Z"),
                (u"И", u"I"),
                (u"Й", u"J"),
                (u"К", u"K"),
                (u"Л", u"L"),
                (u"М", u"M"),
                (u"Н", u"N"),
                (u"О", u"O"),
                (u"П", u"P"),
                (u"Р", u"R"),
                (u"С", u"S"),
                (u"Т", u"T"),
                (u"У", u"U"),
                (u"Ф", u"F"),
                (u"Х", u"H"),
                (u"Ц", u"C"),
                (u"Ъ", u"#"),
                (u"Ь", u"'"),

                ## lower
                # three-symbols replacements
                (u"щ", u"shh"),

                # two-symbols replacements
                (u"ё", u"jo"),
                (u"ж", u"zh"),
                (u"ч", u"ch"),
                (u"ш", u"sh"),
                (u"ы", u"y"),
                (u"э", u"je"),
                (u"ю", u"ju"),
                (u"я", u"ja"),

                # one-symbol replacements
                (u"а", u"a"),
                (u"б", u"b"),
                (u"в", u"v"),
                (u"г", u"g"),
                (u"д", u"d"),
                (u"е", u"e"),
                (u"з", u"z"),
                (u"и", u"i"),
                (u"й", u"j"),
                (u"к", u"k"),
                (u"л", u"l"),
                (u"м", u"m"),
                (u"н", u"n"),
                (u"о", u"o"),
                (u"п", u"p"),
                (u"р", u"r"),
                (u"с", u"s"),
                (u"т", u"t"),
                (u"у", u"u"),
                (u"ф", u"f"),
                (u"х", u"h"),
                (u"ц", u"c"),
                (u"щ", u"w"),
                (u"ъ", u"#"),
                (u"ь", u"'"),

                # Make english alphabet full: append english-english pairs
                # for symbols which is not used in russian-english
                # translations. Used in slugify.
                (u"c", u"c"),
                (u"q", u"q"),
                (u"y", u"y"),
                (u"x", u"x"),
                (u"w", u"w"),
                (u"1", u"1"),
                (u"2", u"2"),
                (u"3", u"3"),
                (u"4", u"4"),
                (u"5", u"5"),
                (u"6", u"6"),
                (u"7", u"7"),
                (u"8", u"8"),
                (u"9", u"9"),
                (u"0", u"0"),
                )  #: Translation table

    def detranslify(self, in_string):
        russian = unicode(in_string)
        for symb_out, symb_in in self.transtable:
          russian = russian.replace(symb_in, symb_out)
        return russian

    def translify(self, in_string):
        translit = unicode(in_string)
        for symb_out, symb_in in self.transtable:
          translit = translit.replace(symb_out, symb_in)
        return translit

#    def alphabet(self):
#      RU_ALPHABET = [x[0] for x in self.transtable] #: Russian alphabet that we can translate
#      print RU_ALPHABET


#RU_ALPHABET = [x[0] for x in TRANSTABLE] #: Russian alphabet that we can translate
#EN_ALPHABET = [x[1] for x in TRANSTABLE] #: English alphabet that we can detransliterate
#ALPHABET = RU_ALPHABET + EN_ALPHABET #: Alphabet that we can (de)transliterate

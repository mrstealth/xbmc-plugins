#!/usr/bin/python
# Writer (c) 2012, MrStealth
# Rev. 1.0.1

import os, sys
import xbmc, xbmcaddon
import simplejson as json

__addon__ = xbmcaddon.Addon(id='script.module.translit')
__cwd__ = __addon__.getAddonInfo('path')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__author__ = __addon__.getAddonInfo('author')
__language__ = __addon__.getLocalizedString
__profile__ = xbmc.translatePath( __addon__.getAddonInfo('profile') ).decode("utf-8")
__resource__ = xbmc.translatePath( os.path.join( __cwd__, 'lib' ) ).decode("utf-8")

sys.path.append (__resource__)

print "\n "
print "****** Info ******"
print "Addon: %s"%__addon__
print "Cwd: %s"%__cwd__
print "Scriptname: %s"%__scriptname__
print "Version: %s"%__version__
print "Author: %s"%__author__
print "Language: %s"%__language__
print "Profile: %s"%__profile__
print "Resource: %s"%__resource__
print "****** end ******\n"

class Translit():
    def __init__(self, encoding='utf-8'):
        self.encoding = encoding
        self.transtable = self.getTranstable()

    def getTranstable(self):
        try:
            file_path = os.path.join(__resource__, "transtable.json" )
            json_tuple = open(file_path).read()

            try:
              transtable = json.loads(json_tuple)
              return transtable
            except Exception, e:
              print e
              return ()

        except IOError, e:
            print e
            return ()

    def rus(self, in_string):
        russian = unicode(in_string)
        for symb_out, symb_in in self.transtable:
          russian = russian.replace(symb_in, symb_out)
        return russian.encode(self.encoding)

    def eng(self, in_string):
        translit = unicode(in_string)
        for symb_out, symb_in in self.transtable:
          translit = translit.replace(symb_out, symb_in)
        return translit.encode(self.encoding)

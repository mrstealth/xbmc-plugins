import xbmc
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.favorites')
plugin = "Favorites-1.0.3"
